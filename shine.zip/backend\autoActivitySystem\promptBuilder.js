function buildPostPrompt({ user, postType, news, targetText }) {
  return `You simulate one realistic social media user.
User: ${user.name} (@${user.username}), bio: ${user.description || 'n/a'}
Post type: ${postType}
Hot news: ${news.map((n, i) => `${i}. ${n.title} - ${n.description || ''}`).join('\n') || 'none'}
Reply target (for critique only): ${targetText || 'none'}
Write human text, no template, varied tone. For every non-poll post, base the factual claims on one or more of the supplied news items and return their zero-based indexes. Never invent a source. Polls must return an empty sourceIndexes array.
Output JSON: {"text":"...", "keywords":["..."], "sourceIndexes":[0], "pollOptions":["...optional..."]}`;
}

function buildArticlePrompt({ user, news }) {
  return `Write a natural human article for ${user.name} (@${user.username}) based on trending discussions and hot news.
News: ${news.map((n, i) => `${i}. ${n.title} - ${n.description || ''}`).join('\n') || 'none'}
Base factual claims on one or more supplied news items. Never invent a source. Output JSON: {"title":"...", "content":"...", "sourceIndexes":[0]}`;
}

function buildCommentsPrompt({ postText, postType, actors, count }) {
  return `Generate ${count} distinct, natural comments that directly respond to this ${postType} post:
${postText}
Commenting profiles:
${actors.map((actor, index) => `${index}. ${actor.name} (@${actor.username}), bio: ${actor.description || 'n/a'}`).join('\n')}
Match each profile's likely voice, avoid generic filler, do not mention being AI, and do not repeat the post. Output JSON: {"comments":[{"actorIndex":0,"text":"..."}]}`;
}

module.exports = { buildPostPrompt, buildArticlePrompt, buildCommentsPrompt };
