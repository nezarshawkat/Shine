require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const redis = require("redis");
const prisma = require("./prisma.js");
const { OAuth2Client } = require("google-auth-library");
const { startDigestScheduler } = require("./services/notificationDigestService");
const { startAutoActivitySystem } = require("./autoActivitySystem");
const dataService = require("./services/dataService");
const { startSyncEngine } = require("./sync/syncEngine");
const localUsers = require("./services/localUserService");
const { LOCAL_UPLOAD_ROOT } = require("./lib/supabaseStorage");
const { ensureSeededAccounts } = require("./services/seededAccountService");
const { ensureDefaultAdmin } = require("./services/defaultAdminService");

const { pingRouter, startping } = require("./ping");

const app = express();
const PORT = process.env.PORT || 5000;
const server = http.createServer(app);
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const localOnly =
  process.env.DATABASE_MODE === "local" ||
  process.env.LOCAL_ONLY_DB === "true" ||
  !process.env.DATABASE_URL;

// ================= 1. CORS CONFIGURATION =================
// Added your Vercel production URL to the allowed list
const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:3000",
  "https://shine-red.vercel.app", 
  "https://shine-a77g.onrender.com",
  "https://sshine.org"
];

app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (like mobile apps or curl)
      if (!origin) return callback(null, true);
      
      const isAllowed = allowedOrigins.some((url) => origin.startsWith(url)) || 
                        origin.includes("app.github.dev");

      if (isAllowed) {
        callback(null, true);
      } else {
        console.error(`❌ CORS blocked for origin: ${origin}`);
        callback(new Error("Not allowed by CORS"));
      }
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// ================= 2. PAYMENT ROUTES =================
const paymentRoutes = require('./routes/payment');
app.use('/api', paymentRoutes);

// ================= 3. GLOBAL MIDDLEWARE =================
app.use(express.json());
app.use("/uploads", express.static(LOCAL_UPLOAD_ROOT));

// ================= 4. REDIS SETUP =================
let redisClient = null;
if (process.env.ENABLE_REDIS_CACHE === "true") {
  (async () => {
    try {
      redisClient = redis.createClient({ url: process.env.REDIS_URL });
      await redisClient.connect();
      console.log("✅ Redis connected");
      app.set("redisClient", redisClient);
    } catch (err) {
      console.error("❌ Redis failed:", err);
    }
  })();
}

// ================= 5. SOCKET.IO =================
let io = null;
if (process.env.ENABLE_SOCKET_IO === "true") {
  io = new Server(server, { 
    cors: { 
      origin: allowedOrigins, 
      methods: ["GET", "POST"],
      credentials: true
    } 
  });
  app.set("io", io);
  io.on("connection", (socket) => {
    socket.on("join", (userId) => socket.join(userId));
  });
}

// ================= 6. ROUTES =================
app.use("/api/users", require("./routes/auth.routes.js"));
app.use("/api/users", require("./routes/users.js"));
app.use("/api/follow", require("./routes/follow"));
app.use("/api/events", localOnly ? require("./routes/localEvents") : require("./routes/events"));
app.use("/api/upload", require("./routes/upload"));
app.use("/api/posts", require("./routes/posts"));
app.use("/api/communities", require("./routes/communities"));
app.use("/api/messenger", localOnly ? require("./routes/localMessenger.js") : require("./routes/messenger.js"));
app.use("/api/articles", localOnly ? require("./routes/localArticles") : require("./routes/articles"));
app.use("/api", require("./routes/comments")); 
app.use("/api/admin", localOnly ? require("./routes/localAdmin") : require("./routes/admin"));
app.use("/api/reports", require("./routes/reports"));
app.use("/api/support", require("./routes/support"));
app.use("/api/email-notifications", require("./routes/emailNotifications"));
app.use("/api/indexnow", require("./routes/indexnow"));
app.use("/share", require("./routes/sharePreview"));

// ================= 7. PING =================
app.use("/", pingRouter); // Ping endpoint
startping();               // Automatic interval every 30 seconds

// ================= 8. Health Checks =================
// Lightweight endpoint for uptime monitors. Does not touch the database.
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    environment: process.env.NODE_ENV,
    database: "not-checked",
  });
});

// Deep health endpoint for manual diagnostics or platform checks that must validate DB connectivity.
app.get("/health/db", async (req, res) => {
  if (localOnly) {
    return res.json({
      status: "ok",
      environment: process.env.NODE_ENV,
      database: "local-sqlite",
      localDatabase: dataService.getStatus(),
    });
  }

  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({
      status: "ok",
      environment: process.env.NODE_ENV,
      database: "ok",
      localDatabase: dataService.getStatus(),
    });
  } catch (e) {
    res.status(500).json({
      status: "error",
      error: e.message,
      database: "down",
      localDatabase: dataService.getStatus(),
    });
  }
});

// ================= 9. Google Auth Route =================
app.post("/api/auth/google", async (req, res) => {
  try {
    const { token } = req.body;
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: process.env.GOOGLE_CLIENT_ID
    });

    const payload = ticket.getPayload();
    const { email, name, sub: googleId } = payload;

    if (localOnly) {
      const user = localUsers.upsertGoogleUser({
        email,
        name,
        googleId,
        image: payload.picture,
      });
      return res.json({ success: true, user });
    }

    const user = await prisma.user.upsert({
      where: { email },
      update: { name, googleId },
      create: {
        email,
        name,
        googleId,
        provider: "google"
      }
    });

    res.json({ success: true, user });
  } catch (err) {
    console.error("Google Auth Error:", err);
    res.status(401).json({ success: false, message: "Invalid Google Token" });
  }
});

// ================= 10. START SERVER =================
if (localOnly) {
  console.log("Starting Shine in local-only SQLite mode.");
  startAutoActivitySystem({ respectEnv: true });
} else {
  startDigestScheduler();
  startAutoActivitySystem({ respectEnv: true });
  dataService
    .bootstrapLocalCache()
    .then((count) => {
      if (count) console.log(`Hybrid local cache bootstrapped with ${count} recent posts`);
    })
    .catch((error) => console.error("Hybrid local cache bootstrap failed:", error.message));
  startSyncEngine();
}
Promise.all([
  ensureSeededAccounts(localOnly ? null : prisma),
  ensureDefaultAdmin(localOnly ? null : prisma),
]).then(([seededCount]) => {
  console.log(`Seeded account pool ready (${seededCount} accounts).`);
}).catch((error) => console.error("Startup seed failed:", error.message));
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
