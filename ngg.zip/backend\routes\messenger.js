const express = require('express');
const router = express.Router();
const prisma = require('../prisma');
const auth = require('../middleware/auth');
const blockFilterFor = (userId) => ({
  AND: [
    { sender: { blockedUsers: { none: { blockedId: userId } } } },
    { sender: { blockedBy: { none: { blockerId: userId } } } },
    { receiver: { blockedUsers: { none: { blockedId: userId } } } },
    { receiver: { blockedBy: { none: { blockerId: userId } } } },
  ],
});

/**
 * 1. GET INBOX SUMMARY (For Sidebar)
 * Retrieves the last 3 unique conversations for a quick preview
 */
router.get('/inbox', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    // Get messages relevant to the user, excluding those they deleted
    const messages = await prisma.message.findMany({
      where: {
        OR: [{ senderId: userId }, { receiverId: userId }],
        NOT: { deletedBy: { has: userId } },
        ...blockFilterFor(userId),
      },
      orderBy: { createdAt: 'desc' },
      include: {
        sender: { select: { id: true, username: true, name: true } },
        receiver: { select: { id: true, username: true, name: true } }
      }
    });

    const chatPartners = new Map();
    messages.forEach((msg) => {
      const partner = msg.senderId === userId ? msg.receiver : msg.sender;
      if (!partner) return;

      if (!chatPartners.has(partner.id)) {
        chatPartners.set(partner.id, {
          _id: partner.id,
          participantName: partner.name || partner.username,
          participantUsername: partner.username,
          lastMessage: msg.text || "📷 Image",
          lastMessageDate: msg.createdAt,
          isRead: msg.receiverId === userId ? msg.isRead : true,
          unread: false,
          unreadCount: 0
        });
      }

      const existingChat = chatPartners.get(partner.id);
      if (msg.receiverId === userId && !msg.isRead) {
        existingChat.unreadCount += 1;
        existingChat.unread = true;
        existingChat.isRead = false;
      }
    });

    // Return only the top 3 most recent unique conversations
    res.json(Array.from(chatPartners.values()).slice(0, 3));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * 2. SEND MESSAGE
 * Logic includes friendship checks and a safety wrapper for notifications
 */
router.post('/send', auth, async (req, res) => {
  try {
    const { receiverId, text, imageUrl } = req.body;
    const senderId = req.user.id;
    const trimmedText = typeof text === 'string' ? text.trim() : '';

    if (!receiverId) return res.status(400).json({ error: "Receiver ID is required" });
    if (!trimmedText && !imageUrl) return res.status(400).json({ error: "Message content cannot be empty" });

    if (receiverId === senderId) {
      return res.status(400).json({ error: "You cannot message yourself." });
    }

    const receiver = await prisma.user.findUnique({
      where: { id: receiverId },
      select: { id: true }
    });

    if (!receiver) {
      return res.status(404).json({ error: "Receiver not found" });
    }

    const blockedRelation = await prisma.block.findFirst({
      where: {
        OR: [
          { blockerId: senderId, blockedId: receiverId },
          { blockerId: receiverId, blockedId: senderId },
        ],
      },
    });
    if (blockedRelation) {
      return res.status(403).json({ error: "Messaging is unavailable for this user." });
    }

    const message = await prisma.message.create({
      data: { senderId, receiverId, text: trimmedText || null, imageUrl },
      include: { sender: { select: { username: true, image: true } } }
    });

    // Notify safely - failure here should not block the response
    try {
      await prisma.notification.create({
        data: {
          userId: receiverId,
          type: "MESSAGE",
          content: `${message.sender.username} sent you a message.`,
          link: `/messenger`
        }
      });
    } catch (e) { 
      console.error("Notification log only:", e.message); 
    }

    res.status(201).json(message);
  } catch (err) {
    console.error("Messenger Send Error:", err);
    res.status(500).json({ error: "Server error while sending message" });
  }
});

/**
 * 3. GET CONVERSATIONS
 * Retrieves all unique chat conversations for the main Messenger view
 */
router.get('/conversations', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const messages = await prisma.message.findMany({
      where: {
        OR: [{ senderId: userId }, { receiverId: userId }],
        NOT: { deletedBy: { has: userId } },
        ...blockFilterFor(userId),
      },
      orderBy: { createdAt: 'desc' },
      include: {
        sender: { select: { id: true, name: true, username: true, image: true } },
        receiver: { select: { id: true, name: true, username: true, image: true } }
      }
    });

    const chatPartners = new Map();
    messages.forEach((msg) => {
      const partner = msg.senderId === userId ? msg.receiver : msg.sender;
      if (!partner) return;

      if (!chatPartners.has(partner.id)) {
        chatPartners.set(partner.id, {
          user: partner,
          lastMessage: msg.text || "Image",
          lastMessageDate: msg.createdAt,
          isRead: msg.receiverId === userId ? msg.isRead : true,
          unreadCount: 0
        });
      }

      const conversation = chatPartners.get(partner.id);
      if (msg.receiverId === userId && !msg.isRead) {
        conversation.unreadCount += 1;
        conversation.isRead = false;
      }
    });

    res.json(Array.from(chatPartners.values()));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * 4. GET CHAT HISTORY
 * Fetches individual messages between two users and marks unread ones as read
 */
router.get('/history/:partnerId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const { partnerId } = req.params;

    await prisma.emailNotificationPreference.upsert({
      where: { userId },
      update: { lastMessengerViewedAt: new Date() },
      create: {
        userId,
        lastMessengerViewedAt: new Date(),
        lastNotifiedAt: new Date(0),
      },
    });

    // Update incoming messages as 'read'
    await prisma.message.updateMany({
      where: { 
        senderId: partnerId, 
        receiverId: userId, 
        isRead: false 
      },
      data: { isRead: true }
    });

    const history = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: userId, receiverId: partnerId },
          { senderId: partnerId, receiverId: userId }
        ],
        NOT: { deletedBy: { has: userId } },
        ...blockFilterFor(userId),
      },
      orderBy: { createdAt: 'asc' }
    });

    res.json(history);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: 'Message text is required' });
    }

    const existing = await prisma.message.findUnique({ where: { id } });
    if (!existing) return res.status(404).json({ error: 'Message not found' });
    if (existing.senderId !== req.user.id) return res.status(403).json({ error: 'Not allowed' });

    const updated = await prisma.message.update({
      where: { id },
      data: { text: text.trim() }
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const message = await prisma.message.findUnique({ where: { id } });

    if (!message) return res.status(404).json({ error: 'Message not found' });
    if (message.senderId !== req.user.id && message.receiverId !== req.user.id) {
      return res.status(403).json({ error: 'Not allowed' });
    }

    const deletedBy = Array.from(new Set([...(message.deletedBy || []), req.user.id]));
    await prisma.message.update({ where: { id }, data: { deletedBy } });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/conversation/:partnerId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const { partnerId } = req.params;

    const conversationMessages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: userId, receiverId: partnerId },
          { senderId: partnerId, receiverId: userId }
        ]
      },
      select: { id: true, deletedBy: true }
    });

    await Promise.all(
      conversationMessages.map((msg) => {
        const deletedBy = Array.from(new Set([...(msg.deletedBy || []), userId]));
        return prisma.message.update({ where: { id: msg.id }, data: { deletedBy } });
      })
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});




router.get('/search', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const term = (req.query.q || '').trim();

    if (!term) return res.json([]);

    const users = await prisma.user.findMany({
      where: {
        AND: [
          { id: { not: userId } },
          { provider: { not: 'engagement' } },
          {
            OR: [
              { username: { contains: term, mode: 'insensitive' } },
              { name: { contains: term, mode: 'insensitive' } }
            ],
          },
          { blockedUsers: { none: { blockedId: userId } } },
          { blockedBy: { none: { blockerId: userId } } },
        ],
      },
      select: { id: true, username: true, name: true, image: true },
      take: 20,
      orderBy: { name: 'asc' }
    });

    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/system', auth, async (req, res) => {
  try {
    const data = await prisma.notification.findMany({
      where: { userId: req.user.id, type: 'SYSTEM' },
      orderBy: { createdAt: 'desc' }
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/system/:id/read', auth, async (req, res) => {
  try {
    const data = await prisma.notification.update({
      where: { id: req.params.id },
      data: { isRead: true }
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/system/read-all', auth, async (req, res) => {
  try {
    await prisma.notification.updateMany({
      where: {
        userId: req.user.id,
        type: 'SYSTEM',
        isRead: false
      },
      data: { isRead: true }
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
