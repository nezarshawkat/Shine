const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET || "shine-super-secret-key";

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: "No token provided" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = { id: decoded.userId || decoded.id };
    if (!req.user.id) {
      return res.status(401).json({ error: "Invalid token" });
    }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid token" });
  }
}

module.exports = authMiddleware;
